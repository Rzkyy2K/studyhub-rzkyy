import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\SchoolSessionController::switchMethod
 * @see app/Http/Controllers/SchoolSessionController.php:15
 * @route '/session/switch'
 */
export const switchMethod = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: switchMethod.url(options),
    method: 'post',
})

switchMethod.definition = {
    methods: ["post"],
    url: '/session/switch',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SchoolSessionController::switchMethod
 * @see app/Http/Controllers/SchoolSessionController.php:15
 * @route '/session/switch'
 */
switchMethod.url = (options?: RouteQueryOptions) => {
    return switchMethod.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SchoolSessionController::switchMethod
 * @see app/Http/Controllers/SchoolSessionController.php:15
 * @route '/session/switch'
 */
switchMethod.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: switchMethod.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SchoolSessionController::switchMethod
 * @see app/Http/Controllers/SchoolSessionController.php:15
 * @route '/session/switch'
 */
    const switchMethodForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: switchMethod.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SchoolSessionController::switchMethod
 * @see app/Http/Controllers/SchoolSessionController.php:15
 * @route '/session/switch'
 */
        switchMethodForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: switchMethod.url(options),
            method: 'post',
        })
    
    switchMethod.form = switchMethodForm
/**
* @see \App\Http\Controllers\SchoolSessionController::extend
 * @see app/Http/Controllers/SchoolSessionController.php:29
 * @route '/session/extend'
 */
export const extend = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: extend.url(options),
    method: 'post',
})

extend.definition = {
    methods: ["post"],
    url: '/session/extend',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SchoolSessionController::extend
 * @see app/Http/Controllers/SchoolSessionController.php:29
 * @route '/session/extend'
 */
extend.url = (options?: RouteQueryOptions) => {
    return extend.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SchoolSessionController::extend
 * @see app/Http/Controllers/SchoolSessionController.php:29
 * @route '/session/extend'
 */
extend.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: extend.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SchoolSessionController::extend
 * @see app/Http/Controllers/SchoolSessionController.php:29
 * @route '/session/extend'
 */
    const extendForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: extend.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SchoolSessionController::extend
 * @see app/Http/Controllers/SchoolSessionController.php:29
 * @route '/session/extend'
 */
        extendForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: extend.url(options),
            method: 'post',
        })
    
    extend.form = extendForm
/**
* @see \App\Http\Controllers\SchoolSessionController::startCycle
 * @see app/Http/Controllers/SchoolSessionController.php:42
 * @route '/session/start-cycle'
 */
export const startCycle = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: startCycle.url(options),
    method: 'post',
})

startCycle.definition = {
    methods: ["post"],
    url: '/session/start-cycle',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SchoolSessionController::startCycle
 * @see app/Http/Controllers/SchoolSessionController.php:42
 * @route '/session/start-cycle'
 */
startCycle.url = (options?: RouteQueryOptions) => {
    return startCycle.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SchoolSessionController::startCycle
 * @see app/Http/Controllers/SchoolSessionController.php:42
 * @route '/session/start-cycle'
 */
startCycle.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: startCycle.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SchoolSessionController::startCycle
 * @see app/Http/Controllers/SchoolSessionController.php:42
 * @route '/session/start-cycle'
 */
    const startCycleForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: startCycle.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SchoolSessionController::startCycle
 * @see app/Http/Controllers/SchoolSessionController.php:42
 * @route '/session/start-cycle'
 */
        startCycleForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: startCycle.url(options),
            method: 'post',
        })
    
    startCycle.form = startCycleForm
const SchoolSessionController = { switchMethod, extend, startCycle, switch: switchMethod }

export default SchoolSessionController