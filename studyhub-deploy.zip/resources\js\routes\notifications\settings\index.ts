import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Settings\NotificationSettingsController::edit
 * @see app/Http/Controllers/Settings/NotificationSettingsController.php:20
 * @route '/settings/notifications'
 */
export const edit = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/settings/notifications',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Settings\NotificationSettingsController::edit
 * @see app/Http/Controllers/Settings/NotificationSettingsController.php:20
 * @route '/settings/notifications'
 */
edit.url = (options?: RouteQueryOptions) => {
    return edit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\NotificationSettingsController::edit
 * @see app/Http/Controllers/Settings/NotificationSettingsController.php:20
 * @route '/settings/notifications'
 */
edit.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Settings\NotificationSettingsController::edit
 * @see app/Http/Controllers/Settings/NotificationSettingsController.php:20
 * @route '/settings/notifications'
 */
edit.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Settings\NotificationSettingsController::edit
 * @see app/Http/Controllers/Settings/NotificationSettingsController.php:20
 * @route '/settings/notifications'
 */
    const editForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Settings\NotificationSettingsController::edit
 * @see app/Http/Controllers/Settings/NotificationSettingsController.php:20
 * @route '/settings/notifications'
 */
        editForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Settings\NotificationSettingsController::edit
 * @see app/Http/Controllers/Settings/NotificationSettingsController.php:20
 * @route '/settings/notifications'
 */
        editForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Settings\NotificationSettingsController::preferences
 * @see app/Http/Controllers/Settings/NotificationSettingsController.php:45
 * @route '/settings/notifications/preferences'
 */
export const preferences = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: preferences.url(options),
    method: 'put',
})

preferences.definition = {
    methods: ["put"],
    url: '/settings/notifications/preferences',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Settings\NotificationSettingsController::preferences
 * @see app/Http/Controllers/Settings/NotificationSettingsController.php:45
 * @route '/settings/notifications/preferences'
 */
preferences.url = (options?: RouteQueryOptions) => {
    return preferences.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\NotificationSettingsController::preferences
 * @see app/Http/Controllers/Settings/NotificationSettingsController.php:45
 * @route '/settings/notifications/preferences'
 */
preferences.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: preferences.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Settings\NotificationSettingsController::preferences
 * @see app/Http/Controllers/Settings/NotificationSettingsController.php:45
 * @route '/settings/notifications/preferences'
 */
    const preferencesForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: preferences.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\NotificationSettingsController::preferences
 * @see app/Http/Controllers/Settings/NotificationSettingsController.php:45
 * @route '/settings/notifications/preferences'
 */
        preferencesForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: preferences.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    preferences.form = preferencesForm
/**
* @see \App\Http\Controllers\Settings\NotificationSettingsController::subscribe
 * @see app/Http/Controllers/Settings/NotificationSettingsController.php:68
 * @route '/settings/notifications/subscribe'
 */
export const subscribe = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: subscribe.url(options),
    method: 'post',
})

subscribe.definition = {
    methods: ["post"],
    url: '/settings/notifications/subscribe',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Settings\NotificationSettingsController::subscribe
 * @see app/Http/Controllers/Settings/NotificationSettingsController.php:68
 * @route '/settings/notifications/subscribe'
 */
subscribe.url = (options?: RouteQueryOptions) => {
    return subscribe.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\NotificationSettingsController::subscribe
 * @see app/Http/Controllers/Settings/NotificationSettingsController.php:68
 * @route '/settings/notifications/subscribe'
 */
subscribe.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: subscribe.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Settings\NotificationSettingsController::subscribe
 * @see app/Http/Controllers/Settings/NotificationSettingsController.php:68
 * @route '/settings/notifications/subscribe'
 */
    const subscribeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: subscribe.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\NotificationSettingsController::subscribe
 * @see app/Http/Controllers/Settings/NotificationSettingsController.php:68
 * @route '/settings/notifications/subscribe'
 */
        subscribeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: subscribe.url(options),
            method: 'post',
        })
    
    subscribe.form = subscribeForm
/**
* @see \App\Http\Controllers\Settings\NotificationSettingsController::unsubscribe
 * @see app/Http/Controllers/Settings/NotificationSettingsController.php:99
 * @route '/settings/notifications/unsubscribe'
 */
export const unsubscribe = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: unsubscribe.url(options),
    method: 'post',
})

unsubscribe.definition = {
    methods: ["post"],
    url: '/settings/notifications/unsubscribe',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Settings\NotificationSettingsController::unsubscribe
 * @see app/Http/Controllers/Settings/NotificationSettingsController.php:99
 * @route '/settings/notifications/unsubscribe'
 */
unsubscribe.url = (options?: RouteQueryOptions) => {
    return unsubscribe.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\NotificationSettingsController::unsubscribe
 * @see app/Http/Controllers/Settings/NotificationSettingsController.php:99
 * @route '/settings/notifications/unsubscribe'
 */
unsubscribe.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: unsubscribe.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Settings\NotificationSettingsController::unsubscribe
 * @see app/Http/Controllers/Settings/NotificationSettingsController.php:99
 * @route '/settings/notifications/unsubscribe'
 */
    const unsubscribeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: unsubscribe.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\NotificationSettingsController::unsubscribe
 * @see app/Http/Controllers/Settings/NotificationSettingsController.php:99
 * @route '/settings/notifications/unsubscribe'
 */
        unsubscribeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: unsubscribe.url(options),
            method: 'post',
        })
    
    unsubscribe.form = unsubscribeForm
/**
* @see \App\Http\Controllers\Settings\NotificationSettingsController::testPush
 * @see app/Http/Controllers/Settings/NotificationSettingsController.php:123
 * @route '/settings/notifications/test-push'
 */
export const testPush = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: testPush.url(options),
    method: 'post',
})

testPush.definition = {
    methods: ["post"],
    url: '/settings/notifications/test-push',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Settings\NotificationSettingsController::testPush
 * @see app/Http/Controllers/Settings/NotificationSettingsController.php:123
 * @route '/settings/notifications/test-push'
 */
testPush.url = (options?: RouteQueryOptions) => {
    return testPush.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\NotificationSettingsController::testPush
 * @see app/Http/Controllers/Settings/NotificationSettingsController.php:123
 * @route '/settings/notifications/test-push'
 */
testPush.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: testPush.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Settings\NotificationSettingsController::testPush
 * @see app/Http/Controllers/Settings/NotificationSettingsController.php:123
 * @route '/settings/notifications/test-push'
 */
    const testPushForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: testPush.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\NotificationSettingsController::testPush
 * @see app/Http/Controllers/Settings/NotificationSettingsController.php:123
 * @route '/settings/notifications/test-push'
 */
        testPushForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: testPush.url(options),
            method: 'post',
        })
    
    testPush.form = testPushForm
/**
* @see \App\Http\Controllers\Settings\NotificationSettingsController::testWhatsApp
 * @see app/Http/Controllers/Settings/NotificationSettingsController.php:158
 * @route '/settings/notifications/test-wa'
 */
export const testWhatsApp = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: testWhatsApp.url(options),
    method: 'post',
})

testWhatsApp.definition = {
    methods: ["post"],
    url: '/settings/notifications/test-wa',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Settings\NotificationSettingsController::testWhatsApp
 * @see app/Http/Controllers/Settings/NotificationSettingsController.php:158
 * @route '/settings/notifications/test-wa'
 */
testWhatsApp.url = (options?: RouteQueryOptions) => {
    return testWhatsApp.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\NotificationSettingsController::testWhatsApp
 * @see app/Http/Controllers/Settings/NotificationSettingsController.php:158
 * @route '/settings/notifications/test-wa'
 */
testWhatsApp.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: testWhatsApp.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Settings\NotificationSettingsController::testWhatsApp
 * @see app/Http/Controllers/Settings/NotificationSettingsController.php:158
 * @route '/settings/notifications/test-wa'
 */
    const testWhatsAppForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: testWhatsApp.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\NotificationSettingsController::testWhatsApp
 * @see app/Http/Controllers/Settings/NotificationSettingsController.php:158
 * @route '/settings/notifications/test-wa'
 */
        testWhatsAppForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: testWhatsApp.url(options),
            method: 'post',
        })
    
    testWhatsApp.form = testWhatsAppForm
const settings = {
    edit: Object.assign(edit, edit),
preferences: Object.assign(preferences, preferences),
subscribe: Object.assign(subscribe, subscribe),
unsubscribe: Object.assign(unsubscribe, unsubscribe),
testPush: Object.assign(testPush, testPush),
testWhatsApp: Object.assign(testWhatsApp, testWhatsApp),
}

export default settings