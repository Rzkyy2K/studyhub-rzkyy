import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\TaskController::reset
 * @see app/Http/Controllers/TaskController.php:222
 * @route '/tasks/history/reset'
 */
export const reset = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reset.url(options),
    method: 'post',
})

reset.definition = {
    methods: ["post"],
    url: '/tasks/history/reset',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TaskController::reset
 * @see app/Http/Controllers/TaskController.php:222
 * @route '/tasks/history/reset'
 */
reset.url = (options?: RouteQueryOptions) => {
    return reset.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::reset
 * @see app/Http/Controllers/TaskController.php:222
 * @route '/tasks/history/reset'
 */
reset.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reset.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TaskController::reset
 * @see app/Http/Controllers/TaskController.php:222
 * @route '/tasks/history/reset'
 */
    const resetForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reset.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskController::reset
 * @see app/Http/Controllers/TaskController.php:222
 * @route '/tasks/history/reset'
 */
        resetForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reset.url(options),
            method: 'post',
        })
    
    reset.form = resetForm
const history = {
    reset: Object.assign(reset, reset),
}

export default history