import DashboardController from './DashboardController'
import TaskController from './TaskController'
import ScheduleController from './ScheduleController'
import TodoController from './TodoController'
import SubjectController from './SubjectController'
import SchoolSessionController from './SchoolSessionController'
import NotificationController from './NotificationController'
import Settings from './Settings'
const Controllers = {
    DashboardController: Object.assign(DashboardController, DashboardController),
TaskController: Object.assign(TaskController, TaskController),
ScheduleController: Object.assign(ScheduleController, ScheduleController),
TodoController: Object.assign(TodoController, TodoController),
SubjectController: Object.assign(SubjectController, SubjectController),
SchoolSessionController: Object.assign(SchoolSessionController, SchoolSessionController),
NotificationController: Object.assign(NotificationController, NotificationController),
Settings: Object.assign(Settings, Settings),
}

export default Controllers