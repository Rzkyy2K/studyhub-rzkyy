import ProfileController from './ProfileController'
import NotificationSettingsController from './NotificationSettingsController'
import SecurityController from './SecurityController'
const Settings = {
    ProfileController: Object.assign(ProfileController, ProfileController),
NotificationSettingsController: Object.assign(NotificationSettingsController, NotificationSettingsController),
SecurityController: Object.assign(SecurityController, SecurityController),
}

export default Settings